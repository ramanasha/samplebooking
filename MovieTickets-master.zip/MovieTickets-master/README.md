# Movie Tickets Booking App with React Native Tutorial

Learn how to build slick animated UIs with React Native by building movie tickets booking app.

## Tutorial

Read the full tutorial here http://rationalappdev.com/movie-tickets-booking-app-with-react-native

## Demo

<img src="https://github.com/rationalappdev/MovieTickets/blob/master/demo.gif" alt="Demo" width="640" />
