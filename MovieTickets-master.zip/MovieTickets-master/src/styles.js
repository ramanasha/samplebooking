export const defaultStyles = {
  text: {
    fontFamily: 'Avenir',
  }
};
